from os import stat
from tkinter import*
from PIL import Image, ImageTk #pip install pillow
from tkinter import ttk
import random
from time import strftime
from datetime import datetime
import mysql.connector
from tkinter import messagebox

class Detailsroom:
    def __init__(self,root):
        self.root=root
        self.root.title("Hotel Management System")
        self.root.geometry("1121x452+234+243")

        ################ Title ##################
        lbl_title = Label(self.root,text="ROOMBOOKING DETAILS",font=("times new roman",18,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE)
        lbl_title.place(x=0,y=0,width=1121,height=35)

        ################## Logo ######################
        img2 = Image.open("logohotel.png")
        img2 = img2.resize((100,35),Image.ANTIALIAS)
        self.photoimg2=ImageTk.PhotoImage(img2)

        lblimg = Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=0,width=100,height=35)

        ################ LABEL FRAME ###################
        lblFrameLeft=LabelFrame(self.root,bd=2,relief=RIDGE,text="NEW ROOM ADD",font=("times new roman",12,"bold"),padx=2)
        lblFrameLeft.place(x=5,y=40,width=460,height=410)

        ############## FLOOR #################
        lbl_floor= Label(lblFrameLeft,text="FLOOR ",font=("arial",10,"bold"),padx=2,pady=6)
        lbl_floor.grid(row=0,column=0,sticky=W)
        
        self.var_floor=StringVar()
        entry_floor = ttk.Entry(lblFrameLeft,textvariable=self.var_floor,width=20,font=("arial",11,"bold"))
        entry_floor.grid(row=0,column=1,sticky=W)

        ############## ROOM NUMBER #################
        lbl_room_no= Label(lblFrameLeft,text="ROOM NO. ",font=("arial",10,"bold"),padx=2,pady=6)
        lbl_room_no.grid(row=1,column=0,sticky=W)
        
        self.var_room_no=StringVar()
        entry_room_no = ttk.Entry(lblFrameLeft,textvariable=self.var_room_no,width=20,font=("arial",11,"bold"))
        entry_room_no.grid(row=1,column=1,sticky=W)

        ############## ROOM TYPE #################
        lblroom_type=Label(lblFrameLeft,text="ROOM TYPE :",font=("arial",10,"bold"),padx=2,pady=6)
        lblroom_type.grid(row=2,column=0,sticky=W)

        conn = mysql.connector.connect(host="localhost",username="root",password="1234",database="hotel")
        my_cursor = conn.cursor()
        my_cursor.execute("Select ROOM_TYPE from details")
        data_rows = my_cursor.fetchall()
        
        self.var_room_type=StringVar()
        combo_room_type = ttk.Combobox(lblFrameLeft,textvariable=self.var_room_type,font=("arial",10,"bold"),width=20,stat="readonly")
        combo_room_type["value"]=("SINGLE","DUPLEX","LAXUARY")
        combo_room_type.current(0)
        combo_room_type.grid(row=2,column=1)


        ############## ROOM Status #################
        lbl_room_status= Label(lblFrameLeft,text="ROOM STATUS. ",font=("arial",10,"bold"),padx=2,pady=6)
        lbl_room_status.grid(row=3,column=0,sticky=W)

        conn = mysql.connector.connect(host="localhost",username="root",password="1234",database="hotel")
        my_cursor = conn.cursor()
        my_cursor.execute("Select ROOM_STATUS from details")
        data_rows = my_cursor.fetchall()

        self.var_room_status=StringVar()
        combo_room_status = ttk.Combobox(lblFrameLeft,textvariable=self.var_room_status,font=("arial",10,"bold"),width=20,stat="readonly")
        combo_room_status["value"]=("AVAILABLE","BOOKED")
        combo_room_status.current(0)
        combo_room_status.grid(row=3,column=1,sticky=W)

        ############## BUTTONS ##############
        btn_frame = Label(lblFrameLeft,bd=2,relief=RIDGE)
        btn_frame.place(x=15,y=200,width=412,height=32)

        btn_add = Button(btn_frame,text="ADD",command=self.add_data,font=("arial",10,"bold"),bg="black",fg="gold",width=10)
        btn_add.grid(row=0,column=0,padx=5)

        btn_update = Button(btn_frame,text="UPDATE",command=self.update,font=("arial",10,"bold"),bg="black",fg="gold",width=10)
        btn_update.grid(row=0,column=1,padx=5)

        btn_delete = Button(btn_frame,text="DELETE",command=self.dat_Delete,font=("arial",10,"bold"),bg="black",fg="gold",width=10)
        btn_delete.grid(row=0,column=2,padx=5)

        btn_reset = Button(btn_frame,text="RESET",command=self.reset,font=("arial",10,"bold"),bg="black",fg="gold",width=10)
        btn_reset.grid(row=0,column=3,padx=5)

        ############## TABLE FRAME SEARCH ###############        
        table_frame=LabelFrame(self.root,bd=2,relief=RIDGE,text="SHOW ROOM DETAILS",font=("times new roman",12,"bold"),padx=2)
        table_frame.place(x=500,y=40,width=618,height=350)



        lblsearchby = Label(table_frame,text="SEARCH BY :",font=("arial",10,"bold"),bg="red",fg="white")
        lblsearchby.grid(row=0,column=0,sticky=W,padx=4)

        self.search_var = StringVar()

        combo_search=ttk.Combobox(table_frame,textvariable=self.search_var,font=("arial",10,"bold"),width=12,state="readonly")
        combo_search["value"]=("FLOOR","ROOM_TYPE","ROOM_STATUS")
        combo_search.current(0)
        combo_search.grid(row=0,column=1,padx=4)

        self.txt_search = StringVar()
        entry_search = ttk.Entry(table_frame,textvariable=self.txt_search,width=29,font=("arial",11,"bold"))
        entry_search.grid(row=0,column=2,padx=4)

        btn_search = Button(table_frame,text="SEARCH",command=self.search_data,font=("arial",10,"bold"),bg="black",fg="gold",width=6)
        btn_search.grid(row=0,column=3,padx=5)

        btn_showall = Button(table_frame,text="SHOW ALL",command=self.fetch_data,font=("arial",10,"bold"),bg="black",fg="gold",width=8)
        btn_showall.grid(row=0,column=4,padx=5)



         ############## TABLE SEARCH ###############        
        table_frame=LabelFrame(self.root,bd=2,relief=RIDGE)
        table_frame.place(x=500,y=100,width=618,height=350)

        Scroll_x=ttk.Scrollbar(table_frame,orient=HORIZONTAL)
        Scroll_y=ttk.Scrollbar(table_frame,orient=VERTICAL)

        self.room_table=ttk.Treeview(table_frame,columns=("FLOOR","ROOM_NO","ROOM_TYPE","ROOM_STATUS"),xscrollcommand=Scroll_x.set,yscrollcommand=Scroll_y.set)
        Scroll_x.pack(side=BOTTOM,fill=X)
        Scroll_y.pack(side=RIGHT,fill=Y)

        Scroll_x.config(command=self.room_table.xview)
        Scroll_y.config(command=self.room_table.yview)

        self.room_table.heading("FLOOR",text="FLOOR")
        self.room_table.heading("ROOM_NO",text="ROOM NO.")
        self.room_table.heading("ROOM_TYPE",text="ROOM TYPE")
        self.room_table.heading("ROOM_STATUS",text="ROOM STATUS")

        self.room_table["show"]="headings"

        self.room_table.column("FLOOR",width=100)
        self.room_table.column("ROOM_NO",width=100)
        self.room_table.column("ROOM_TYPE",width=100)
        self.room_table.column("ROOM_STATUS",width=100)

        self.room_table.pack(fill=BOTH,expand=1)
        self.room_table.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()
        


    def search_data(self):
        conn = mysql.connector.connect(host="localhost",username="root",password="1234",database="hotel")
        my_cursor = conn.cursor()
        my_cursor.execute("select * from details where "+str(self.search_var.get())+" LIKE '%"+str(self.txt_search.get())+"%'")
        rows_featch = my_cursor.fetchall()
        if len(rows_featch)!=0:
            self.room_table.delete(*self.room_table.get_children())
            for i in rows_featch:
                self.room_table.insert("",END,values=i)
            conn.commit()
        conn.close()

    def add_data(self):
        if self.var_floor.get()=="" or self.var_room_type.get()=="":
            messagebox.showerror("Error","ALL FIELDS ARE REQUIRED!!!",parent=self.root)
        else:
            try:
                conn = mysql.connector.connect(host="localhost",username="root",password="1234",database="hotel")
                my_cursor = conn.cursor()
                my_cursor.execute("insert into details values(%s,%s,%s,%s)",(self.var_floor.get(),self.var_room_no.get(),self.var_room_type.get(),self.var_room_status.get()))
                conn.commit()
                self.fetch_data()
                conn.close()
                messagebox.showinfo("Success","New Room added succeccfully!!!",parent=self.root)
            except Exception as es:
                messagebox.showwarning("Warning",f"Some thing went wrong:{str(es)}",parent=self.root)

    def fetch_data(self):
        conn =  mysql.connector.connect(host="localhost",username="root",password="1234",database="hotel")
        my_cursor = conn.cursor()
        my_cursor.execute("Select * from details")
        rows = my_cursor.fetchall()
        if len(rows)!= 0:
            self.room_table.delete(*self.room_table.get_children())
            for i in rows:
                self.room_table.insert("",END,values=i)
            conn.commit()
        conn.close()

    def get_cursor(self,event=""):
        cursor_row = self.room_table.focus()
        content = self.room_table.item(cursor_row)
        row = content["values"]

        self.var_floor.set(row[0]),
        self.var_room_no.set(row[1]),
        self.var_room_type.set(row[2])
        self.var_room_status.set(row[3])

    def update(self):
        if self.var_floor.get()=="":
            messagebox.showerror("Error","Please enter floor number",parent=self.root)
        else:
            conn =  mysql.connector.connect(host="localhost",username="root",password="1234",database="hotel")
            my_cursor = conn.cursor()
            my_cursor.execute("update details set FLOOR=%s,ROOM_TYPE=%s,ROOM_STATUS=%s where ROOM_NO=%s",(self.var_floor.get(),self.var_room_type.get(),self.var_room_status.get(),self.var_room_no.get(),))
            conn.commit()
            self.fetch_data()
            conn.close()
            messagebox.showinfo("Update","NEW Room details has been updated sucessfully",parent=self.root)

    def dat_Delete(self):
        dat_Delete = messagebox.askyesno("Hotel Management System,","Do you want to remove this room detail",parent=self.root)
        if dat_Delete>0:
            conn =  mysql.connector.connect(host="localhost",username="root",password="1234",database="hotel")
            my_cursor = conn.cursor()
            query = "delete from details where ROOM_NO=%s"
            value = (self.var_room_no.get(),)
            my_cursor.execute(query,value)
        else:
            if not dat_Delete:
                return
        conn.commit()
        self.fetch_data()
        conn.close()

    def reset(self):
        self.var_floor.set(""),
        self.var_room_no.set(""),
        self.var_room_type.set("")
        self.var_room_status.set("")


    





if __name__ == "__main__":
    root=Tk()
    Obj=Detailsroom(root)
    root.mainloop()

